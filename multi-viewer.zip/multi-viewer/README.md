# Multi-Viewer — Pared de clientes de streaming concurrentes

Contenedor Docker que expone una página web con una **cuadrícula de N reproductores HLS**, cada uno con una conexión de red independiente al servidor de streaming. Sirve para **visualizar la degradación simultánea** del servicio de video durante un ataque DDoS sobre la red SDN.

Rol en el experimento: actor **"Cliente legítimo"** del diagrama de secuencia, pero **multiplicado N veces** para obtener evidencia visual clara del impacto.

## Para qué sirve en la tesis

| Momento del experimento | Lo que se observa |
|-------------------------|-------------------|
| **Antes del ataque** | Las N celdas reproducen el video sincronizado, buffer estable (~4 s) |
| **Durante el ataque** | Las celdas entran en estado `buffering` (borde amarillo parpadeante), contador de cortes sube, buffer cae a 0 |
| **Después del ataque** | Las celdas vuelven a `playing` (borde verde), confirmando la recuperación |

Capturar la pantalla en cada fase produce evidencia visual directa para la sustentación de la tesis: una imagen vale más que un gráfico de RTT.

## Despliegue

```bash
cd ~/multi-viewer
docker compose up -d
```

Abrir en el navegador:

```
http://<IP_DEL_HOST>:8080
```

## Configuración en la UI

| Campo | Valor por defecto | Descripción |
|-------|-------------------|-------------|
| **Servidor de streaming** | `192.168.10.66` | IP del servidor MediaMTX |
| **Puerto HLS** | `8888` | Puerto HLS expuesto por MediaMTX |
| **Stream path** | `live/stream1` | Path publicado: `stream1` (720p), `stream2` (480p), `hd` (1080p) |
| **Cantidad de clientes** | `12` | Número de viewers concurrentes (1–64) |

Botones:

- **▶ Iniciar todos** — abre las N conexiones HLS
- **■ Detener** — cierra todas
- **+1 cliente** — añade un viewer extra sin tocar los existentes

Atajos: `Espacio` inicia, `Esc` detiene, `+` añade uno.

## Métricas mostradas

### Por cada viewer (footer de la celda)

| Métrica | Significado |
|---------|-------------|
| **Buffer** | Segundos de video pre-cargados. Cae a 0 cuando la red no entrega segmentos a tiempo. |
| **Cortes** | Número de eventos `waiting` (el reproductor se detuvo a esperar datos). |
| **Frames** | Cuadros decodificados acumulados. Si deja de subir, el video está congelado. |
| **Tiempo** | Tiempo de reproducción actual. |

### Agregadas (header)

| Métrica | Significado |
|---------|-------------|
| **Total** | Viewers activos en la cuadrícula |
| **Reproduciendo** | En estado `playing` (borde verde) |
| **Cargando** | En `buffering` (borde amarillo parpadeante) |
| **Con error** | En `error` (borde rojo) |
| **Buffer prom.** | Promedio de segundos pre-cargados — indicador clave de salud |
| **Cortes total** | Suma de cortes en todos los viewers |

## Códigos de color por celda

| Borde | Estado | Significado |
|-------|--------|-------------|
| 🟢 Verde fijo | `playing` | Reproducción fluida |
| 🟡 Amarillo parpadeante | `buffering` | Esperando datos |
| 🔴 Rojo fijo | `error` | Conexión rota o stream no disponible |

## Cómo se relaciona con el ataque

Cada celda mantiene una conexión HLS independiente (HTTP GET periódico al `.m3u8` y a los segmentos `.ts`). Estas conexiones atraviesan el plano de datos del switch OVS gestionado por el controlador SDN.

Durante la **Fase 2** del experimento (tiempo de ejecución del ataque):

1. El controlador SDN se satura por la inundación de los bots.
2. Los nuevos flujos requeridos por las re-peticiones HLS (cada segmento puede abrir conexión nueva) sufren retardo de instalación.
3. Los viewers ven sus buffers caer y entran en estado `buffering`.
4. El contador "Cortes total" sube rápidamente.

Al detener el ataque (**Fase 3**), las celdas vuelven progresivamente a `playing` — la recuperación de la red SDN se observa en directo.

## Topología recomendada

```
┌────────────────────────────┐         ┌─────────────────┐
│ Multi-Viewer (este Docker) │ ──HLS── │ MediaMTX server │
│ 192.168.10.99:8080         │         │ 192.168.10.66   │
└────────────────────────────┘         └─────────────────┘
              │                                  │
              └───────  red SDN (OVS) ───────────┘
                              │
                  ┌───────────┴───────────┐
                  │  Controlador SDN      │
                  │  192.168.10.6:6633    │  ← objetivo de los bots
                  └───────────────────────┘
```

Colocar el contenedor multi-viewer en una máquina **distinta** de los bots, de manera que su tráfico también pase por el switch SDN. Si los viewers estuvieran en la misma máquina que el servidor de streaming no se notaría la degradación de red.

## Diagnóstico

| Síntoma | Causa probable | Solución |
|---------|----------------|----------|
| Todas las celdas en `error` desde el inicio | URL HLS mal formada o servidor no accesible | Verificar `curl http://<server>:8888/live/stream1/index.m3u8` |
| Las celdas funcionan localmente pero no desde otra máquina | CORS rechazado por el navegador | Revisar `nginx.conf` (ya incluye `Access-Control-Allow-Origin *`) |
| El navegador se congela con muchos viewers | Saturación del lado cliente (CPU/RAM) | Reducir el número de viewers a 16-24 |
| Las celdas vienen al estado `buffering` sin haber lanzado ataque | Saturación del servidor de streaming o del enlace | Verificar `docker logs mediamtx` y CPU del servidor |

## Limitaciones conocidas

- **HLS añade ~3-5 s de latencia** intrínseca. Para observar el momento exacto del corte hay un pequeño desfase frente al instante real del ataque. El stream `live/stream1` está configurado en MediaMTX como `hlsVariant: lowLatency` para reducir esto.
- El conteo de `frames decodificados` solo está disponible en navegadores basados en Chromium/Firefox. En Safari aparece como 0.
- A partir de ~32 viewers el navegador puede saturarse antes que la red. Para experimentos con cargas mayores, ejecutar varias instancias del multi-viewer en máquinas distintas.

## Estructura del proyecto

```
multi-viewer/
├── docker-compose.yml      ← define el contenedor nginx
├── nginx.conf              ← config nginx + CORS abierto
├── web/
│   └── index.html          ← SPA completa (HTML+CSS+JS con hls.js)
└── README.md               ← este archivo
```
