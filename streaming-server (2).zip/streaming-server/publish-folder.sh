#!/bin/sh
# ════════════════════════════════════════════════════════════════
# publish-folder.sh — Reproduce todos los videos de una carpeta
#                     en bucle continuo via RTSP hacia MediaMTX.
#
# Parámetros conforme a Tabla XXXII de la tesis (simulación):
#   Resolución      854x480 (480p)
#   Códec video     H.264 Baseline @ Level 3.1
#   Bitrate video   800 kbps
#   FPS             25
#   Códec audio     AAC-LC
#   Bitrate audio   128 kbps
#   Sample rate     48 kHz
#
# Variables de entorno (sobreescribibles desde docker-compose):
#   MEDIA_DIR    directorio con los archivos (default: /media)
#   RTSP_URL     destino RTSP (default: rtsp://mediamtx:8554/live/media)
#   VIDEO_BR     bitrate de video (default: 800k)
#   AUDIO_BR     bitrate de audio (default: 128k)
#   RESOLUCION   resolucion forzada (default: 854x480)
#   FPS          frames por segundo (default: 25)
#   SAMPLE_RATE  frecuencia de muestreo audio (default: 48000)
# ════════════════════════════════════════════════════════════════
set -e

MEDIA_DIR="${MEDIA_DIR:-/media}"
RTSP_URL="${RTSP_URL:-rtsp://mediamtx:8554/live/media}"
VIDEO_BR="${VIDEO_BR:-800k}"
AUDIO_BR="${AUDIO_BR:-128k}"
RESOLUCION="${RESOLUCION:-854x480}"
FPS="${FPS:-25}"
SAMPLE_RATE="${SAMPLE_RATE:-48000}"
PLAYLIST="/tmp/playlist.txt"

# Separar resolución en width x height para los filtros scale/pad
WIDTH=$(echo "$RESOLUCION" | cut -d'x' -f1)
HEIGHT=$(echo "$RESOLUCION" | cut -d'x' -f2)
# Bufsize 2x bitrate
VIDEO_BR_NUM=$(echo "$VIDEO_BR" | sed 's/k$//')
BUFSIZE="$((VIDEO_BR_NUM * 2))k"

echo "════════════════════════════════════════════════════════"
echo "  Publicador de carpeta — Streaming RTSP (Tabla XXXII)"
echo "════════════════════════════════════════════════════════"
echo "  Carpeta:      $MEDIA_DIR"
echo "  Destino:      $RTSP_URL"
echo "  Resolucion:   ${WIDTH}x${HEIGHT} @ ${FPS} fps"
echo "  Codec video:  H.264 Baseline @ ${VIDEO_BR}"
echo "  Codec audio:  AAC-LC @ ${AUDIO_BR} / ${SAMPLE_RATE} Hz"
echo "════════════════════════════════════════════════════════"

# Esperar a que MediaMTX este listo
echo "[*] Esperando a MediaMTX..."
sleep 5

while true; do
    # ── Generar playlist con todos los videos de la carpeta ─────
    echo "[*] Escaneando $MEDIA_DIR..."
    : > "$PLAYLIST"
    find "$MEDIA_DIR" -type f \
        \( -iname "*.mp4" -o -iname "*.mkv" -o -iname "*.avi" \
           -o -iname "*.mov" -o -iname "*.webm" -o -iname "*.ts" \
           -o -iname "*.flv" \) \
        | sort \
        | while read -r f; do
            escaped=$(printf "%s" "$f" | sed "s/'/'\\\\''/g")
            echo "file '$escaped'" >> "$PLAYLIST"
        done

    n=$(wc -l < "$PLAYLIST" 2>/dev/null || echo 0)

    if [ "$n" = "0" ]; then
        echo "[!] No hay videos en $MEDIA_DIR. Esperando 15s..."
        echo "    Coloca archivos .mp4/.mkv/.avi/.mov en la carpeta."
        sleep 15
        continue
    fi

    echo "[*] $n archivos en la playlist:"
    cat "$PLAYLIST" | sed 's/^/      /'
    echo

    # ── Lanzar ffmpeg conforme a Tabla XXXII ───────────────────
    # -stream_loop -1   : bucle infinito sin EOF
    # -fflags +genpts   : regenera PTS para transiciones limpias
    # scale + pad       : ajusta a 854x480 manteniendo aspect ratio
    # libx264 baseline  : Tabla XXXII (compatibilidad amplia)
    # fps=25, g=50      : 25 fps con GOP de 2 s
    # aresample async   : sincronia audio entre archivos
    # aac_low (LC)      : Tabla XXXII
    echo "[*] Iniciando transmision a $RTSP_URL"
    ffmpeg -hide_banner -loglevel warning \
        -stream_loop -1 \
        -re -fflags +genpts -f concat -safe 0 -i "$PLAYLIST" \
        -map 0:v:0 -map 0:a:0? \
        \
        -vf "scale=${WIDTH}:${HEIGHT}:force_original_aspect_ratio=decrease,pad=${WIDTH}:${HEIGHT}:(ow-iw)/2:(oh-ih)/2,format=yuv420p,fps=${FPS}" \
        -c:v libx264 \
        -preset veryfast \
        -profile:v baseline \
        -level 3.1 \
        -tune zerolatency \
        -b:v "$VIDEO_BR" -maxrate "$VIDEO_BR" -bufsize "$BUFSIZE" \
        -g "$((FPS * 2))" -keyint_min "$FPS" -sc_threshold 0 \
        -pix_fmt yuv420p \
        \
        -af "aresample=async=1:first_pts=0,aformat=sample_fmts=fltp:sample_rates=${SAMPLE_RATE}:channel_layouts=stereo" \
        -c:a aac \
        -profile:a aac_low \
        -b:a "$AUDIO_BR" -ar "$SAMPLE_RATE" -ac 2 \
        \
        -vsync cfr \
        -max_muxing_queue_size 9999 \
        -f rtsp -rtsp_transport tcp \
        "$RTSP_URL" || true

    echo "[!] FFmpeg termino. Reiniciando en 3s..."
    sleep 3
done
