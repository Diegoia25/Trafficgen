# Servidor de streaming — Laboratorio GNS3

Servidor RTSP/HLS/WebRTC basado en **MediaMTX** + **FFmpeg** en contenedores Docker. Reemplaza a una cámara IP real dentro de la topología GNS3 del experimento de DDoS sobre red SDN.

Rol en el diagrama de secuencia: actor **"Servidor de video (streaming)"**. IP asignada en el lab: **192.168.10.66**.

## Componentes

| Servicio | Imagen | Función |
|----------|--------|---------|
| `mediamtx` | `bluenviron/mediamtx:latest` | Servidor multiprotocolo: recibe los flujos publicados y los expone a clientes |
| `stream1` | `linuxserver/ffmpeg:latest` | Publica un patrón 720p @ 25 fps · 1.5 Mbps |
| `stream2` | `linuxserver/ffmpeg:latest` | Publica un patrón 480p @ 25 fps · 800 kbps |
| `stream-hd` | `linuxserver/ffmpeg:latest` | Publica un patrón 1080p @ 30 fps · 4 Mbps (alta carga) |
| `webplayer` | `nginx:alpine` | Portal web con player HLS embebido |

Tres calidades distintas permiten comparar el impacto del ataque DDoS sobre diferentes tasas de bits.

## Puertos expuestos

| Puerto | Protocolo | Uso |
|--------|-----------|-----|
| 80 | HTTP | Portal web (player HLS) |
| 8554 | TCP/UDP | RTSP — lo consumen los clientes legítimos y los bots |
| 8888 | HTTP | HLS (acceso desde navegador) |
| 8889 | HTTP | WebRTC (latencia mínima) |
| 1935 | TCP | RTMP (publicación alternativa) |
| 8890 | UDP | SRT |
| 9997 | HTTP | API REST de MediaMTX |
| 9998 | HTTP | Métricas Prometheus |

## Requisitos

- Docker 24+
- Docker Compose v2
- 2 GB de RAM libres (los tres FFmpeg consumen aproximadamente 1.2 GB)
- Puertos del host libres (en particular 80, 8554, 8888)

## Despliegue

```bash
cd ~/streaming-server
docker compose up -d
```

Verificar que los cuatro contenedores estén corriendo:

```bash
docker compose ps
```

Salida esperada:

```
NAME            STATUS              PORTS
mediamtx        Up (healthy)        0.0.0.0:8554->8554/tcp, ...
stream-sd       Up                  
stream-sd2      Up                  
stream-hd       Up                  
streaming-web   Up                  0.0.0.0:80->80/tcp
```

Tras 15-20 segundos los tres FFmpeg habrán terminado de publicar sus flujos y los streams estarán disponibles.

## URLs de acceso

| Recurso | URL |
|---------|-----|
| Portal web (HLS) | `http://192.168.10.66/` |
| RTSP 720p | `rtsp://192.168.10.66:8554/live/stream1` |
| RTSP 480p | `rtsp://192.168.10.66:8554/live/stream2` |
| RTSP 1080p | `rtsp://192.168.10.66:8554/live/hd` |
| HLS 720p | `http://192.168.10.66:8888/live/stream1/index.m3u8` |
| API estado | `http://192.168.10.66:9997/v3/paths/list` |
| Métricas | `http://192.168.10.66:9998/metrics` |

## Verificación local

Reproducir con FFplay:

```bash
ffplay rtsp://192.168.10.66:8554/live/stream1
```

O con VLC:

```bash
vlc rtsp://192.168.10.66:8554/live/stream1
```

Confirmar publicación vía API:

```bash
curl -s http://192.168.10.66:9997/v3/paths/list | jq .
```

Debe listar los tres paths con `ready: true`.

## Integración con el traffic-generator

En la UI del dashboard (modo C2), apuntar los bots RTSP al servidor:

| Campo | Valor |
|-------|-------|
| **IP servidor RTSP** | `192.168.10.66` |
| **Puerto** | `8554` |
| **Stream path** | `live/stream1` |
| **Clientes por bot** | 10–50 según el experimento |

Los bots abrirán múltiples sesiones RTSP simultáneas hacia este servidor, generando el tráfico de "camuflaje" descrito en la **Fase 1** del diagrama de secuencia.

## Topología GNS3

Conectar el host Docker al switch OVS administrado por el controlador SDN. Configuración de red recomendada:

```
eth0 (GNS3 lab)  →  192.168.10.66/24
                    gateway 192.168.10.1
                    MTU 1500
```

El tráfico RTSP de los clientes hacia este servidor pasará por la red SDN, por lo que la saturación del controlador degradará la entrega del video — esto es lo que se mide en la tesis.

## Modificaciones para experimentos

### Cambiar la resolución / bitrate de un stream

Editar el `entrypoint` correspondiente en `docker-compose.yml`. Por ejemplo, para reducir `stream1` a 360p:

```yaml
-f lavfi -i testsrc2=size=640x360:rate=25
-b:v 500k -maxrate 500k -bufsize 1000k
```

Luego:

```bash
docker compose up -d --build stream1
```

### Sustituir el patrón sintético por un video real

Montar el archivo y cambiar la fuente de FFmpeg de `testsrc2` a `-i /media/video.mp4`:

```yaml
volumes:
  - ./media:/media:ro
entrypoint: >
  /bin/sh -c "ffmpeg -re -stream_loop -1 -i /media/video.mp4 ..."
```

### Añadir autenticación RTSP (opcional)

En `mediamtx.yml`, sustituir `authMethod: "no"` por:

```yaml
authMethod: internal
authInternalUsers:
  - user: cliente
    pass: rtspdemo123
    ips: []
    permissions:
      - action: read
        path: live/stream1
```

## Diagnóstico

| Síntoma | Causa probable | Solución |
|---------|----------------|----------|
| `docker compose ps` muestra los FFmpeg en `Restarting` | MediaMTX aún no escucha en 8554 | Esperar el healthcheck (≤20 s). Si persiste: `docker logs mediamtx` |
| Cliente RTSP da "Connection refused" | Puerto 8554 bloqueado por firewall del host | `sudo ufw allow 8554/tcp` |
| Video se corta cada pocos segundos | Saturación de CPU en el host | Reducir `-preset` o eliminar `stream-hd` |
| API devuelve `paths: []` | Los FFmpeg no están publicando | `docker logs stream-sd` y verificar errores de codec |
| Portal web carga pero el player queda en negro | El navegador no soporta HLS nativo | Usar Chrome/Firefox actual (hls.js incluido) o probar con VLC |

## Apagado

```bash
docker compose down
```

Para eliminar también los volúmenes y la red:

```bash
docker compose down -v
```

## Estructura del repositorio

```
streaming-server/
├── docker-compose.yml      ← orquestación de los 5 contenedores
├── mediamtx.yml            ← configuración del servidor MediaMTX
├── web/
│   └── index.html          ← portal web con player HLS embebido
└── README.md               ← este archivo
```

## Referencias

- MediaMTX: https://github.com/bluenviron/mediamtx
- FFmpeg RTSP muxer: https://ffmpeg.org/ffmpeg-protocols.html#rtsp
- hls.js: https://github.com/video-dev/hls.js/
