#!/bin/sh
# ════════════════════════════════════════════════════════════════
# publish-folder.sh — Reproduce todos los videos de una carpeta
#                     en bucle continuo via RTSP hacia MediaMTX.
#
# Variables de entorno:
#   MEDIA_DIR   directorio con los archivos (default: /media)
#   RTSP_URL    destino RTSP (default: rtsp://mediamtx:8554/live/media)
#   VIDEO_BR    bitrate de video (default: 1500k)
#   AUDIO_BR    bitrate de audio (default: 128k)
#   RESOLUCION  resolucion forzada (default: 1280x720)
#   FPS         frames por segundo (default: 25)
# ════════════════════════════════════════════════════════════════
set -e

MEDIA_DIR="${MEDIA_DIR:-/media}"
RTSP_URL="${RTSP_URL:-rtsp://mediamtx:8554/live/media}"
VIDEO_BR="${VIDEO_BR:-1500k}"
AUDIO_BR="${AUDIO_BR:-128k}"
RESOLUCION="${RESOLUCION:-1280x720}"
FPS="${FPS:-25}"
PLAYLIST="/tmp/playlist.txt"

echo "════════════════════════════════════════════════════════"
echo "  Publicador de carpeta — Streaming RTSP"
echo "════════════════════════════════════════════════════════"
echo "  Carpeta:     $MEDIA_DIR"
echo "  Destino:     $RTSP_URL"
echo "  Resolucion:  $RESOLUCION @ $FPS fps"
echo "  Bitrate:     $VIDEO_BR video / $AUDIO_BR audio"
echo "════════════════════════════════════════════════════════"

# Esperar a que MediaMTX este listo
echo "[*] Esperando a MediaMTX..."
sleep 5

while true; do
    # ── Generar playlist con todos los videos de la carpeta ─────
    echo "[*] Escaneando $MEDIA_DIR..."
    : > "$PLAYLIST"
    find "$MEDIA_DIR" -type f \
        \( -iname "*.mp4" -o -iname "*.mkv" -o -iname "*.avi" \
           -o -iname "*.mov" -o -iname "*.webm" -o -iname "*.ts" \
           -o -iname "*.flv" \) \
        | sort \
        | while read -r f; do
            # Escapar comillas simples para el concat demuxer
            escaped=$(printf "%s" "$f" | sed "s/'/'\\\\''/g")
            echo "file '$escaped'" >> "$PLAYLIST"
        done

    n=$(wc -l < "$PLAYLIST" 2>/dev/null || echo 0)

    if [ "$n" = "0" ]; then
        echo "[!] No hay videos en $MEDIA_DIR. Esperando 15s..."
        echo "    Coloca archivos .mp4/.mkv/.avi/.mov en la carpeta."
        sleep 15
        continue
    fi

    echo "[*] $n archivos en la playlist:"
    cat "$PLAYLIST" | sed 's/^/      /'
    echo

    # ── Lanzar ffmpeg con concat + transcoding ─────────────────
    echo "[*] Iniciando transmision a $RTSP_URL"
    ffmpeg -hide_banner -loglevel warning \
        -re -f concat -safe 0 -i "$PLAYLIST" \
        -vf "scale=$RESOLUCION,fps=$FPS,drawtext=fontcolor=white:fontsize=24:box=1:boxcolor=black@0.5:x=10:y=10:text='LIVE %{localtime\\:%H\\\\\\:%M\\\\\\:%S}'" \
        -c:v libx264 -preset ultrafast -tune zerolatency \
        -profile:v baseline -level 3.1 \
        -b:v "$VIDEO_BR" -maxrate "$VIDEO_BR" -bufsize "$(echo $VIDEO_BR | sed 's/k$//')k" \
        -g "$((FPS * 2))" -keyint_min "$FPS" -sc_threshold 0 \
        -c:a aac -b:a "$AUDIO_BR" -ar 44100 -ac 2 \
        -f rtsp -rtsp_transport tcp \
        "$RTSP_URL" || true

    echo "[!] FFmpeg termino. Reiniciando en 3s..."
    sleep 3
done
