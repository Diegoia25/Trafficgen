# TrafficGen SDN/RTSP — Laboratorio GNS3

Herramienta para experimentar con el impacto de saturacion sobre un controlador
SDN y la calidad de servicio (QoS) percibida por clientes RTSP en una topologia
GNS3 controlada.

Soporta operacion **monolitica** (un solo nodo con UI completa) o **distribuida**
(varios *workers* coordinados desde un *dashboard* central).

---

## Arquitectura

```
                    ┌──────────────────────────┐
                    │  Dashboard (kali-1)      │
                    │  http://192.168.10.97:8090│
                    │  - Topologia             │
                    │  - Graficas agregadas    │
                    │  - Broadcast a workers   │
                    └────────────┬─────────────┘
                                 │ REST (acciones tipadas)
              ┌──────────────────┼──────────────────┐
              │                  │                  │
       ┌──────▼──────┐    ┌──────▼──────┐    ┌──────▼──────┐
       │ Worker 1    │    │ Worker 2    │    │ Worker N    │
       │ Debian1.1-1 │    │ ...         │    │ ...         │
       │ .33         │    │             │    │             │
       └──────┬──────┘    └──────┬──────┘    └──────┬──────┘
              │                  │                  │
              └─────────┬────────┴─────────┬────────┘
                        │                  │
                        ▼                  ▼
            ┌───────────────────┐  ┌──────────────────┐
            │  RTSP Server      │  │  SDN Controller  │
            │  192.168.10.66    │  │  192.168.10.6    │
            │  :554             │  │  :6633 OpenFlow  │
            └───────────────────┘  └──────────────────┘
```

---

## Modos de operacion

| Modo | UI | API tipada | Uso |
|---|---|---|---|
| `standalone` | ✓ | ✓ | Un solo nodo con todo (ideal para pruebas rapidas) |
| `worker` | — | ✓ | Solo motor + API; controlado remotamente |
| `dashboard` | ✓ | proxy | UI central que coordina workers |

Se selecciona con la variable de entorno `MODE`.

---

## Estructura del proyecto

```
traffic-generator/
├── Dockerfile
├── app.py                       # Backend Flask, soporta los 3 modos
├── requirements.txt
├── README.md
├── templates/
│   ├── index.html               # UI standalone
│   └── dashboard.html           # UI distribuida
└── scripts/
    ├── install_docker.sh        # Instala Docker en Debian/Ubuntu/Kali
    ├── build_image.sh           # Construye la imagen trafficgen-sdn
    ├── deploy_worker.sh         # Despliega worker en una VM
    ├── deploy_dashboard.sh      # Despliega dashboard
    └── transfer_to_vm.sh        # Copia el proyecto a una VM via SCP
```

---

## Validacion de seguridad de la API worker

Todos los endpoints `/api/worker/*` validan estrictamente sus parametros:

- **IPs:** debe ser IPv4 valida (validada con `ipaddress.IPv4Address`)
- **Puertos:** entero 1–65535
- **`mode` de ataque:** whitelist `{openflow_flood, tcp_exhaust, udp_flood}`
- **`threads`:** entero 1–100
- **`duration`:** entero 0–86400
- **`count` de clientes RTSP:** entero 1–50
- **Strings:** sin caracteres de control, longitud maxima limitada

**No existe ningun endpoint que ejecute comandos shell arbitrarios.**
El worker solo puede realizar las acciones predefinidas en `app.py`.

---

## Despliegue distribuido en GNS3

Topologia objetivo (ver imagenes del lab):

| Rol | Maquina | IP |
|---|---|---|
| Worker 1 | `Debian1.1-1` (LAN 1) | 192.168.10.33 |
| Worker 2 | `kali-1` (LAN 2)      | 192.168.10.97 |
| Dashboard | recomendado en `kali-1` | 192.168.10.97:8090 |
| RTSP Server | `DebianServerVLC-1` | 192.168.10.66:554 |
| SDN Controller | `Ubuntu22.04Controlador-1` | 192.168.10.6:6633 |

> Si quieres mas workers, puedes agregar contenedores Docker adicionales en el
> mismo host o desplegar mas VMs Linux en LAN1/LAN2.

### Paso 1 — Transferir el proyecto a cada VM

Desde tu maquina (Windows con Git Bash, o desde una VM Linux con acceso a la
topologia):

```bash
cd D:/Claude/traffic-generator

# Worker 1 (Debian1.1-1)
bash scripts/transfer_to_vm.sh root@192.168.10.33

# Worker 2 + Dashboard (kali-1)
bash scripts/transfer_to_vm.sh kali@192.168.10.97
```

### Paso 2 — Instalar Docker en cada VM

```bash
# En Debian1.1-1
ssh root@192.168.10.33
cd ~/trafficgen
sudo bash scripts/install_docker.sh

# En kali-1
ssh kali@192.168.10.97
cd ~/trafficgen
sudo bash scripts/install_docker.sh
```

### Paso 3 — Construir la imagen en cada VM

```bash
# En cada VM
cd ~/trafficgen
sudo bash scripts/build_image.sh
```

### Paso 4 — Desplegar workers

```bash
# En Debian1.1-1
sudo bash scripts/deploy_worker.sh
# → http://192.168.10.33:80

# En kali-1 (worker en puerto 80, dashboard en 8090)
sudo bash scripts/deploy_worker.sh
# → http://192.168.10.97:80
```

### Paso 5 — Desplegar el dashboard

En `kali-1`, despues de tener el worker corriendo:

```bash
sudo bash scripts/deploy_dashboard.sh \
    "http://192.168.10.33:80,http://192.168.10.97:80"
```

Abre el navegador en: **http://192.168.10.97:8090**

---

## Operacion del experimento

Una vez en el dashboard:

### 1. Verifica que los workers aparezcan en verde

El panel izquierdo muestra todos los workers configurados. Deben aparecer con
indicador verde y sus metricas de uptime.

### 2. Lanza clientes RTSP en todos los workers

En el formulario "Broadcast: clientes RTSP":

| Campo | Valor |
|---|---|
| IP servidor RTSP | `192.168.10.66` |
| Puerto | `554` |
| Stream path | `live/stream` |
| Por worker | `5` |

Click en **"Iniciar en workers"**. Cada worker abrira 5 sesiones RTSP.

Las graficas mostraran las sesiones agregadas en estado *Streaming* con su RTT
promedio (debe ser estable, ~5–20 ms en GNS3).

### 3. Lanza el ataque al controlador SDN

En el formulario "Broadcast: ataque al SDN":

| Campo | Valor |
|---|---|
| IP Controlador SDN | `192.168.10.6` |
| Puerto OpenFlow | `6633` |
| Hilos | `10` |
| Modo | `OpenFlow Packet-In Flood` |
| Duracion | `60` (segundos) |

Click en **"Lanzar en workers"**. Todos los workers comenzaran a saturar el
controlador simultaneamente.

### 4. Observa el impacto

- La grafica **"Latencia RTSP promedio"** debe subir abruptamente
- La grafica **"Sesiones RTSP agregadas"** mostrara como las sesiones pasan
  de *Streaming* a *Errores*
- El indicador rojo de **"ATAQUE EN CURSO"** se activara
- El nodo "SDN Controller" en la topologia cambia de purpura a rojo
- Los OVS switches pierden el plano de control y dejan de actualizar tablas
  de flujo, causando que el trafico RTSP se degrade o se corte

### 5. Detener el ataque

Click en **"Detener ataques"** en la barra superior. Observa la **recuperacion
gradual** del servicio en las graficas (los clientes RTSP se reconectan).

---

## Endpoints de la API worker

| Metodo | Ruta | Descripcion |
|---|---|---|
| GET | `/api/worker/info` | Info basica del worker |
| GET | `/api/worker/status` | Estado completo (RTSP + ataques) |
| POST | `/api/worker/rtsp/start` | Iniciar N clientes RTSP |
| POST | `/api/worker/rtsp/stop` | Detener cliente(s) RTSP |
| POST | `/api/worker/attack/start` | Iniciar generacion de trafico |
| POST | `/api/worker/attack/stop` | Detener generacion |
| POST | `/api/worker/shutdown` | Detener toda actividad (no mata el proceso) |

### Ejemplo de uso directo (sin dashboard)

```bash
# Iniciar 3 clientes RTSP en un worker
curl -X POST http://192.168.10.33/api/worker/rtsp/start \
  -H "Content-Type: application/json" \
  -d '{
    "server_ip": "192.168.10.66",
    "server_port": 554,
    "stream_path": "live/stream",
    "count": 3,
    "label": "Camara"
  }'

# Lanzar ataque
curl -X POST http://192.168.10.33/api/worker/attack/start \
  -H "Content-Type: application/json" \
  -d '{
    "target_ip": "192.168.10.6",
    "target_port": 6633,
    "mode": "openflow_flood",
    "threads": 10,
    "duration": 60
  }'

# Ver estado completo
curl http://192.168.10.33/api/worker/status | python3 -m json.tool

# Detener todo
curl -X POST http://192.168.10.33/api/worker/shutdown
```

---

## Troubleshooting

### El worker aparece offline en el dashboard
- Verifica conectividad: `ping <ip-worker>` y `curl http://<ip-worker>/api/worker/info`
- El worker debe usar `--network host` para tomar la IP de la VM directamente
- Revisa logs: `sudo docker logs trafficgen-worker`

### Error "Port is already used" al desplegar
- Cambia el puerto: `PORT=8081 sudo bash scripts/deploy_worker.sh`
- O detiene el contenedor anterior: `sudo docker rm -f trafficgen-worker`

### El ataque no parece afectar al controlador SDN
- Verifica que el controlador realmente acepta conexiones en `:6633`:
  `nc -zv 192.168.10.6 6633`
- Aumenta `threads` y usa modo `openflow_flood` (es el mas efectivo)
- Asegurate de que los switches OVS estan conectados al controlador
- Revisa logs del controlador SDN para ver si esta procesando los Packet-In

### `hping3: Operation not permitted`
- El contenedor necesita la capability `NET_RAW`
- Ya esta incluida en `deploy_worker.sh`, pero si despliegas manualmente
  agrega `--cap-add=NET_RAW`

---

## Limpieza

```bash
# En cada VM
sudo docker rm -f trafficgen-worker trafficgen-dashboard
sudo docker rmi trafficgen-sdn:latest
```

---

## Licencia y uso

Esta herramienta esta diseñada exclusivamente para uso en laboratorios virtuales
controlados (GNS3, EVE-NG, contenedores aislados). No la utilices contra
infraestructura que no sea de tu propiedad o sin autorizacion explicita.
