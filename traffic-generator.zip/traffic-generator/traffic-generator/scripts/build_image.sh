#!/usr/bin/env bash
# ============================================================
# build_image.sh
# Construye la imagen Docker trafficgen-sdn
# Debe ejecutarse desde el directorio del proyecto (donde esta el Dockerfile)
# ============================================================
set -euo pipefail

IMAGE_NAME="${IMAGE_NAME:-trafficgen-sdn}"
IMAGE_TAG="${IMAGE_TAG:-latest}"

echo "[+] Construyendo imagen ${IMAGE_NAME}:${IMAGE_TAG}..."

if [ ! -f Dockerfile ]; then
    echo "[!] No se encuentra Dockerfile en el directorio actual"
    echo "    Ejecuta este script desde D:/Claude/traffic-generator/"
    exit 1
fi

sudo docker build -t "${IMAGE_NAME}:${IMAGE_TAG}" .

echo
echo "[OK] Imagen construida:"
sudo docker images | grep "${IMAGE_NAME}"
