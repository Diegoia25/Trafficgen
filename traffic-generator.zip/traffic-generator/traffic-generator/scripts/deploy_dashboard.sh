#!/usr/bin/env bash
# ============================================================
# deploy_dashboard.sh
# Despliega el contenedor TrafficGen en MODO DASHBOARD
# Pensado para ejecutarse en kali-1 o un nodo de monitoreo
#
# El dashboard:
#   - Expone UI web en el puerto configurado
#   - Sondea workers configurados en WORKERS
#   - Permite lanzar comandos broadcast a todos los workers
#
# Uso:
#   sudo bash deploy_dashboard.sh \
#       "http://192.168.10.33:80,http://192.168.10.34:80"
#
#   PORT=8090 sudo bash deploy_dashboard.sh "http://192.168.10.33:80"
# ============================================================
set -euo pipefail

if [ $# -lt 1 ]; then
    echo "Uso: $0 \"http://worker1:port,http://worker2:port,...\""
    echo
    echo "Ejemplo:"
    echo "  $0 \"http://192.168.10.33:80,http://192.168.10.34:80\""
    exit 1
fi

WORKERS_LIST="$1"
IMAGE_NAME="${IMAGE_NAME:-trafficgen-sdn:latest}"
CONTAINER_NAME="${CONTAINER_NAME:-trafficgen-dashboard}"
PORT="${PORT:-8090}"
NODE_NAME="${NODE_NAME:-dashboard-$(hostname)}"

echo "[+] Desplegando dashboard TrafficGen..."
echo "    Imagen:    $IMAGE_NAME"
echo "    Container: $CONTAINER_NAME"
echo "    Puerto:    $PORT"
echo "    Workers:   $WORKERS_LIST"

# Verificar imagen
if ! sudo docker image inspect "$IMAGE_NAME" >/dev/null 2>&1; then
    echo "[!] La imagen $IMAGE_NAME no existe."
    echo "    Ejecuta primero: bash build_image.sh"
    exit 1
fi

# Detener anterior
if sudo docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    echo "[+] Eliminando contenedor anterior..."
    sudo docker rm -f "$CONTAINER_NAME"
fi

# Lanzar dashboard
echo "[+] Iniciando contenedor..."
sudo docker run -d \
    --name "$CONTAINER_NAME" \
    --restart unless-stopped \
    --network host \
    -e MODE=dashboard \
    -e PORT="$PORT" \
    -e NODE_NAME="$NODE_NAME" \
    -e WORKERS="$WORKERS_LIST" \
    "$IMAGE_NAME"

sleep 2

if sudo docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    HOST_IP=$(hostname -I | awk '{print $1}')
    echo
    echo "[OK] Dashboard desplegado correctamente"
    echo
    echo "     Abre en el navegador:"
    echo "     http://${HOST_IP}:${PORT}"
    echo
    echo "     Workers configurados:"
    IFS=',' read -ra W <<< "$WORKERS_LIST"
    for w in "${W[@]}"; do
        echo "       - $w"
    done
else
    echo "[!] El contenedor no esta corriendo. Ver logs:"
    sudo docker logs "$CONTAINER_NAME"
    exit 1
fi
