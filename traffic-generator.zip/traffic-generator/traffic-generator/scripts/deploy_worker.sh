#!/usr/bin/env bash
# ============================================================
# deploy_worker.sh
# Despliega un contenedor TrafficGen en MODO WORKER
# Pensado para ejecutarse en VMs como Debian1.1-1 o cliente RTSP
#
# El worker:
#   - No expone UI
#   - Acepta solo acciones tipadas via /api/worker/*
#   - Sera controlado remotamente desde el dashboard central
#
# Uso:
#   sudo bash deploy_worker.sh                # puerto 80 por defecto
#   PORT=8080 sudo bash deploy_worker.sh      # puerto custom
# ============================================================
set -euo pipefail

IMAGE_NAME="${IMAGE_NAME:-trafficgen-sdn:latest}"
CONTAINER_NAME="${CONTAINER_NAME:-trafficgen-worker}"
PORT="${PORT:-80}"
NODE_NAME="${NODE_NAME:-$(hostname)}"

echo "[+] Desplegando worker TrafficGen..."
echo "    Imagen:    $IMAGE_NAME"
echo "    Container: $CONTAINER_NAME"
echo "    Puerto:    $PORT"
echo "    Node:      $NODE_NAME"

# Verificar que la imagen existe
if ! sudo docker image inspect "$IMAGE_NAME" >/dev/null 2>&1; then
    echo "[!] La imagen $IMAGE_NAME no existe."
    echo "    Ejecuta primero: bash build_image.sh"
    exit 1
fi

# Detener y eliminar contenedor anterior si existe
if sudo docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    echo "[+] Eliminando contenedor anterior..."
    sudo docker rm -f "$CONTAINER_NAME"
fi

# Lanzar nuevo contenedor en modo worker con red host
echo "[+] Iniciando contenedor..."
sudo docker run -d \
    --name "$CONTAINER_NAME" \
    --restart unless-stopped \
    --cap-add NET_RAW \
    --network host \
    -e MODE=worker \
    -e PORT="$PORT" \
    -e NODE_NAME="$NODE_NAME" \
    "$IMAGE_NAME"

sleep 2

# Verificar
if sudo docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    HOST_IP=$(hostname -I | awk '{print $1}')
    echo
    echo "[OK] Worker desplegado correctamente"
    echo "     URL del worker: http://${HOST_IP}:${PORT}"
    echo
    echo "     Verificacion rapida:"
    echo "     curl http://${HOST_IP}:${PORT}/api/worker/info"
    echo
    echo "     Para registrar este worker en el dashboard, agrega esta URL"
    echo "     a la variable WORKERS del contenedor dashboard."
else
    echo "[!] El contenedor no esta corriendo. Ver logs:"
    sudo docker logs "$CONTAINER_NAME"
    exit 1
fi
