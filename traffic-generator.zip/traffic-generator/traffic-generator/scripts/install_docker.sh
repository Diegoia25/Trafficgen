#!/usr/bin/env bash
# ============================================================
# install_docker.sh
# Instala Docker Engine en Debian/Ubuntu/Kali
# Uso: sudo bash install_docker.sh
# ============================================================
set -euo pipefail

echo "[+] Detectando distribucion..."
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
else
    echo "[!] No se pudo detectar la distribucion"
    exit 1
fi

echo "[+] Distribucion: $DISTRO"

# Verificar si Docker ya esta instalado
if command -v docker >/dev/null 2>&1; then
    echo "[+] Docker ya esta instalado: $(docker --version)"
    sudo systemctl start docker || true
    sudo systemctl enable docker || true
    exit 0
fi

case "$DISTRO" in
    debian|ubuntu)
        echo "[+] Instalando Docker en Debian/Ubuntu..."
        sudo apt-get update -y
        sudo apt-get install -y ca-certificates curl gnupg lsb-release

        sudo install -m 0755 -d /etc/apt/keyrings
        curl -fsSL https://download.docker.com/linux/$DISTRO/gpg | \
            sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
        sudo chmod a+r /etc/apt/keyrings/docker.gpg

        echo \
            "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
            https://download.docker.com/linux/$DISTRO \
            $(lsb_release -cs) stable" | \
            sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

        sudo apt-get update -y
        sudo apt-get install -y docker-ce docker-ce-cli containerd.io
        ;;

    kali)
        echo "[+] Instalando Docker en Kali Linux..."
        sudo apt-get update -y
        sudo apt-get install -y docker.io
        ;;

    *)
        echo "[!] Distribucion no soportada: $DISTRO"
        echo "    Distribuciones soportadas: debian, ubuntu, kali"
        exit 1
        ;;
esac

echo "[+] Iniciando servicio Docker..."
sudo systemctl start docker
sudo systemctl enable docker

echo
echo "[OK] Docker instalado correctamente:"
sudo docker --version
echo
echo "    Para usar docker sin sudo (opcional):"
echo "    sudo usermod -aG docker \$USER"
echo "    (cierra sesion y vuelve a entrar)"
