#!/usr/bin/env bash
# ============================================================
# transfer_to_vm.sh
# Transfiere el proyecto a una VM remota via SCP
#
# Uso desde el host (Windows con Git Bash o desde una VM Linux):
#   bash transfer_to_vm.sh <usuario>@<ip-vm>
#
# Ejemplo:
#   bash transfer_to_vm.sh root@192.168.10.33
#   bash transfer_to_vm.sh kali@192.168.10.97
# ============================================================
set -euo pipefail

if [ $# -lt 1 ]; then
    echo "Uso: $0 <usuario>@<ip-vm> [destino-remoto]"
    echo
    echo "Ejemplos:"
    echo "  $0 root@192.168.10.33"
    echo "  $0 kali@192.168.10.97 ~/trafficgen"
    exit 1
fi

REMOTE="$1"
DEST="${2:-~/trafficgen}"
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "[+] Transfiriendo proyecto a $REMOTE:$DEST"
echo "    Origen: $PROJECT_DIR"

# Crear directorio remoto
ssh "$REMOTE" "mkdir -p $DEST/templates $DEST/scripts"

# Copiar archivos
scp "$PROJECT_DIR/Dockerfile"           "$REMOTE:$DEST/"
scp "$PROJECT_DIR/app.py"               "$REMOTE:$DEST/"
scp "$PROJECT_DIR/requirements.txt"     "$REMOTE:$DEST/"
scp "$PROJECT_DIR/templates/index.html" "$REMOTE:$DEST/templates/"
scp "$PROJECT_DIR/templates/dashboard.html" "$REMOTE:$DEST/templates/"
scp "$PROJECT_DIR/scripts/"*.sh         "$REMOTE:$DEST/scripts/"

# Permisos de ejecucion en los scripts
ssh "$REMOTE" "chmod +x $DEST/scripts/*.sh"

echo
echo "[OK] Transferencia completada"
echo
echo "     Pasos siguientes en la VM remota:"
echo "       ssh $REMOTE"
echo "       cd $DEST"
echo "       sudo bash scripts/install_docker.sh"
echo "       sudo bash scripts/build_image.sh"
echo "       sudo bash scripts/deploy_worker.sh        # si es worker"
echo "       sudo bash scripts/deploy_dashboard.sh ... # si es dashboard"
